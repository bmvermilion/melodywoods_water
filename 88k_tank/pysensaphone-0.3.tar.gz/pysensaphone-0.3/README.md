# pysensaphone
Interface for Sensaphone Sentinel Rest API

https://wiki.sensaphone.net/index.php/Sensaphone.net_API
